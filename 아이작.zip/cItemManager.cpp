#include "stdafx.h"
#include "cItemManager.h"
#include "cPlayer.h"
#include "cSceneManager.h"

HRESULT cItemManager::init(void)
{	
	return S_OK;
}

void cItemManager::release(void)
{


}

void cItemManager::update(void)
{
	for(int i = 0; i < vItem.size(); i++)
	{
		if (_sm->GetCurrentMap() == ��11)
		{
			if (vItem[i].currentmap == ��11)
			{
				if (IntersectRect(&temp,&_player->GetRC(),&vItem[i].rc))
				{
					if (vItem[i].state==����)
					{
						_player->SetKey(_player->GetKey() + 1);
					}
					if (vItem[i].state == ��ź)
					{
						_player->SetBomb(_player->GetBomb() + 1);
					}					
					DeleteItem(i);
				}
			}
		}
		if (_sm->GetCurrentMap() == ��12)
		{
			if (vItem[i].currentmap == ��12)
			{
				if (IntersectRect(&temp, &_player->GetRC(), &vItem[i].rc))
				{
					if (vItem[i].state == ����)
					{
						_player->SetKey(_player->GetKey() + 1);
					}
					if (vItem[i].state == ��ź)
					{
						_player->SetBomb(_player->GetBomb() + 1);
					}
					DeleteItem(i);
				}
			}
		}




	}


	for (int i = 0; i < vNewItem.size(); i++)
	{
		if (_sm->GetCurrentMap() == ��11)
		{
			if (vNewItem[i].currentmap == ��11)
			{
				if (vNewItem[i].state == ����)
				{
					
				}
				if (vNewItem[i].state == ��ź&&vNewItem[i].IsUse == false)
				{

				}
				if (vNewItem[i].state == ��ź&&vNewItem[i].IsUse==true)
				{
					int static nCount = 0;
					nCount++;
					if (nCount>100)
					{
						vNewItem[i].rc = RectMakeCenter(vNewItem[i].x, vNewItem[i].y, BOMBSIZE, BOMBSIZE);
						//KillTimer(_hWnd, 1);
						nCount = 0;						
						DeleteNewItem(i);												
					}
					//cout << nCount << endl;
				}
				
			}
		}
		if (_sm->GetCurrentMap() == ��12)
		{
			if (vNewItem[i].currentmap == ��12)
			{
				if (vNewItem[i].state == ����)
				{

				}
				if (vNewItem[i].state == ��ź&&vNewItem[i].IsUse == false)
				{

				}
				if (vNewItem[i].state == ��ź&&vNewItem[i].IsUse == true)
				{
					int static nCount = 0;
					nCount++;
					if (nCount>100)
					{
						vNewItem[i].rc = RectMakeCenter(vNewItem[i].x, vNewItem[i].y, BOMBSIZE, BOMBSIZE);
						//KillTimer(_hWnd, 1);
						nCount = 0;
						DeleteNewItem(i);						
					}
					//cout << nCount << endl;
				}
			}
		}
	}

}

void cItemManager::render(void)
{
	for (int i = 0; i < vItem.size(); i++)
	{
		if (_sm->GetCurrentMap()==��11)
		{
			if (vItem[i].currentmap == ��11)
			{				
				if (vItem[i].state==����)
				{
					IMAGEMANAGER->render("����", getMemDC(),vItem[i].rc.left, vItem[i].rc.top,0,0,50,50);
				}
				if (vItem[i].state == ��ź)
				{
					IMAGEMANAGER->render("��ź", getMemDC(), vItem[i].rc.left, vItem[i].rc.top,0,0,50,50);
				}
				//RectangleMake(getMemDC(), vItem[i].rc);
			}
		}
		if (_sm->GetCurrentMap() == ��12)
		{
			if (vItem[i].currentmap == ��12)
			{
				if (vItem[i].state == ����)
				{
					IMAGEMANAGER->render("����", getMemDC(), vItem[i].rc.left, vItem[i].rc.top, 0, 0, 50, 50);
				}
				if (vItem[i].state == ��ź)
				{
					IMAGEMANAGER->render("��ź", getMemDC(), vItem[i].rc.left, vItem[i].rc.top, 0, 0, 50, 50);
				}
				//RectangleMake(getMemDC(), vItem[i].rc);
			}
		}
	}


	for (int i = 0; i < vNewItem.size(); i++)
	{
		if (_sm->GetCurrentMap() == ��11)
		{
			if (vNewItem[i].currentmap == ��11)
			{
				if (vNewItem[i].state == ����)
				{
					IMAGEMANAGER->render("����", getMemDC(), _player->GetX(), _player->GetY(), 0, 0, 50, 50);
				}
				if (vNewItem[i].state == ��ź)
				{
					IMAGEMANAGER->render("��ź", getMemDC(), vNewItem[i].x, vNewItem[i].y, 0, 0, 50, 50);
				}				
				RectangleMake(getMemDC(), vNewItem[i].rc);
			}
		}
		if (_sm->GetCurrentMap() == ��12)
		{
			if (vNewItem[i].currentmap == ��12)
			{
				if (vNewItem[i].state == ����)
				{
					IMAGEMANAGER->render("����", getMemDC(), vNewItem[i].rc.left, vNewItem[i].rc.top, 0, 0, 50, 50);
				}
				if (vNewItem[i].state == ��ź)
				{
					IMAGEMANAGER->render("��ź", getMemDC(), vNewItem[i].x, vNewItem[i].y, 0, 0, 50, 50);
				}
			
				RectangleMake(getMemDC(), vNewItem[i].rc);
			}
		}
	}


	TCHAR buffer[256];
	wsprintf(buffer, TEXT("%d"), vItem.size());
	TextOut(getMemDC(), 200, 200, buffer, lstrlen(buffer));


}



void cItemManager::ItemMapSet(float _x, float _y, int _state, int _currentmap)
{
	tag_Item item;
	item.IsUse = false;
	item.x = _x;
	item.y = _y;
	item.state = _state;
	item.currentmap = _currentmap;
	item.rc = RectMakeCenter(item.x, item.y, ITEMSIZE, ITEMSIZE);
	vItem.push_back(item);
}

void cItemManager::ItemUse(int itemNumber, int money)
{
	
	if (itemNumber==��ź)
	{
		_player->SetBomb(_player->GetBomb() - 1);
		tag_Item item;
		item.x = _player->GetX();
		item.y = _player->GetY();
		item.IsUse = true;		
		item.state = ��ź;
		item.currentmap = _sm->GetCurrentMap();
		//item.rc = RectMakeCenter(0, 0, ITEMSIZE, ITEMSIZE); // ��ź�� ������ ��Ʈ������ update()����ó����
		vNewItem.push_back(item);
	}
	if (itemNumber==����)
	{
		_player->SetKey(_player->GetKey() - 1);
	}
	if (itemNumber==����)
	{
		_player->SetMoney(_player->GetMoney() - money);
	}

}

void cItemManager::DeleteItem(int index)
{

	for (int i = 0; i < vItem.size(); i++)
	{
		vItem.erase(vItem.begin() + index);
		break;
	}
}

void cItemManager::DeleteNewItem(int index)
{
	for (int i = 0; i < vNewItem.size(); i++)
	{
		vNewItem.erase(vNewItem.begin() + index);
		break;
	}
}


